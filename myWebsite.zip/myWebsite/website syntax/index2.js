
const inputs = document.querySelectorAll("input");

// Loop
inputs.forEach((input, index) => {
  // change background color
  input.style.backgroundColor = "lightyellow";

  // add number to placeholder
  input.placeholder += ` (${index + 1})`;
});
