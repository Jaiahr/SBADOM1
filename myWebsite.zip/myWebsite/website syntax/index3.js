const p = document.createElement("p");
p.textContent = "The End!";
document.getElementById("ended").appendChild(p);