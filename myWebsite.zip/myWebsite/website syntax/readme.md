This project is to create a website to offer internet boosting services
The index html is the homes page 
The prices html is the table used for pric comparison
the sign in and sign up are forms to enter the website
The javascript is use to interact with my html
html also contains some javascript
https://github.com/Jaiahr/SBADOM1.git
Create by Segundo Guazhambo
